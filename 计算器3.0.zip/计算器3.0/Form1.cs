using System.Diagnostics;

namespace 计算器//上次的改进版，这次用了更好用的.NET
{
    public partial class Form1 : Form
    {
        private string num1 = "";//我C语言会一点，C#应该没问题吧......
        private string num2 = "";
        private string op = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void btnNum_Click(object sender, EventArgs e)//问题多了，这一点也不像C语言
        {
            Button btn = sender as Button;
            string content = btn.Text;
            if (op != "")
            {
                if (content == "." && (num2 == "" || num2.Contains(".")))
                {
                    MessageBox.Show("不能以小数点开头或重复小数点");
                    return;
                }
                else
                {
                    num2 += content;
                    label4.Text = num2;
                }
            }
            if (op == "")
            {
                if (content == "." && (num1 == "" || num1.Contains(".")))
                {
                    MessageBox.Show("不能以小数点开头或重复小数点");
                    return;
                }
                else
                {
                    num1 += content;
                    label4.Text = num1;
                }

            }
            label5.Text = $"{num1} {op} {num2}";
        }
        private void btnOp_Click(object sender, EventArgs e)
        {
            if (num1.EndsWith(".") || num2.EndsWith("."))
            {
                MessageBox.Show("不能以小数点结尾");
                return;
            }
            Button btn = sender as Button;
            string c = btn.Text;
            op = c;
            label5.Text = $"{num1} {op} {num2}";
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            op = "";
            num1 = "";
            num2 = "";
            label5.Text = $"{num1} {op} {num2}";
            label4.Text = num1;
        }
        private void btnEqual_Click(object sender, EventArgs e)
        {
            if (num1.EndsWith(".") || num2.EndsWith("."))
            {
                MessageBox.Show("不能以小数点结尾");
                return;
            }
            if (op == "")
            {
                MessageBox.Show("请先输入操作符");
                return;
            }
            if (num1 == "" || num2 == "")
            {
                MessageBox.Show("数字不能为空");
                return;
            }
            double result = 0;
            double nnum1 = double.Parse(num1);
            double nnum2 = double.Parse(num2);
            switch (op)
            {
                case "+":
                    result = nnum1 + nnum2;
                    break;
                case "-":
                    result = nnum1 - nnum2;
                    break;
                case "*":
                    result = nnum1 * nnum2;
                    break;
                case "/":
                    if (nnum2 == 0)
                    {
                        MessageBox.Show("除数不能为0！");
                        return;
                    }
                    result = nnum1 / nnum2;
                    break;
            }
            num1 = result.ToString();
            num2 = "";
            op = "";
            label5.Text = $"{num1} {op} {num2}";
            label4.Text = num1.ToString();


        }
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("计算器3.0");
        }
        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("C#比Python难写很多，但.NET必须要写C#\n" +
                "......不过.NET写GUI真的很好写，是可视化的，只不过\n" +
                "回调函数什么的要写C#\n" +
                "这个计算器2.0用的就是.NET\n" +
                "不过我得先消化一下C#了......");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)//显示的链接名是“浏览文件”
        {
            Process.Start("explorer.exe");
        }
    }
}
//2.0,有按钮了
//3.0,有小数点了
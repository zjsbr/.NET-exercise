﻿namespace 计算器
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button17 = new Button();
            label5 = new Label();
            button11 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 115);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnNum_Click;
            // 
            // button2
            // 
            button2.Location = new Point(114, 115);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += btnNum_Click;
            // 
            // button3
            // 
            button3.Location = new Point(212, 115);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += btnNum_Click;
            // 
            // button4
            // 
            button4.Location = new Point(12, 166);
            button4.Margin = new Padding(4);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 3;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += btnNum_Click;
            // 
            // button5
            // 
            button5.Location = new Point(114, 166);
            button5.Margin = new Padding(4);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 4;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += btnNum_Click;
            // 
            // button6
            // 
            button6.Location = new Point(212, 166);
            button6.Margin = new Padding(4);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 5;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += btnNum_Click;
            // 
            // button7
            // 
            button7.Location = new Point(12, 217);
            button7.Margin = new Padding(4);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 6;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += btnNum_Click;
            // 
            // button8
            // 
            button8.Location = new Point(114, 217);
            button8.Margin = new Padding(4);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 7;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += btnNum_Click;
            // 
            // button9
            // 
            button9.Location = new Point(212, 217);
            button9.Margin = new Padding(4);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 8;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += btnNum_Click;
            // 
            // button10
            // 
            button10.Location = new Point(114, 274);
            button10.Margin = new Padding(4);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 9;
            button10.Text = "0";
            button10.UseVisualStyleBackColor = true;
            button10.Click += btnNum_Click;
            // 
            // button12
            // 
            button12.Location = new Point(12, 325);
            button12.Margin = new Padding(4);
            button12.Name = "button12";
            button12.Size = new Size(46, 23);
            button12.TabIndex = 11;
            button12.Text = "+";
            button12.UseVisualStyleBackColor = true;
            button12.Click += btnOp_Click;
            // 
            // button13
            // 
            button13.Location = new Point(65, 325);
            button13.Margin = new Padding(4);
            button13.Name = "button13";
            button13.Size = new Size(46, 23);
            button13.TabIndex = 12;
            button13.Text = "-";
            button13.UseVisualStyleBackColor = true;
            button13.Click += btnOp_Click;
            // 
            // button14
            // 
            button14.Location = new Point(116, 325);
            button14.Margin = new Padding(4);
            button14.Name = "button14";
            button14.Size = new Size(46, 23);
            button14.TabIndex = 13;
            button14.Text = "*";
            button14.UseVisualStyleBackColor = true;
            button14.Click += btnOp_Click;
            // 
            // button15
            // 
            button15.Location = new Point(168, 325);
            button15.Margin = new Padding(4);
            button15.Name = "button15";
            button15.Size = new Size(46, 23);
            button15.TabIndex = 14;
            button15.Text = "/";
            button15.UseVisualStyleBackColor = true;
            button15.Click += btnOp_Click;
            // 
            // button16
            // 
            button16.Location = new Point(220, 325);
            button16.Margin = new Padding(4);
            button16.Name = "button16";
            button16.Size = new Size(75, 23);
            button16.TabIndex = 15;
            button16.Text = "=";
            button16.UseVisualStyleBackColor = true;
            button16.Click += btnEqual_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.WindowText;
            label1.Location = new Point(38, 45);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(228, 17);
            label1.TabIndex = 16;
            label1.Text = "                                                       ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.WindowText;
            label2.Location = new Point(38, 62);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(228, 17);
            label2.TabIndex = 17;
            label2.Text = "                                                       ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.WindowText;
            label3.Location = new Point(38, 79);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(228, 17);
            label3.TabIndex = 18;
            label3.Text = "                                                       ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.WindowText;
            label4.Font = new Font("Microsoft YaHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(44, 45);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(48, 28);
            label4.TabIndex = 19;
            label4.Text = "      ";
            // 
            // button17
            // 
            button17.Location = new Point(12, 274);
            button17.Name = "button17";
            button17.Size = new Size(75, 23);
            button17.TabIndex = 20;
            button17.Text = "C";
            button17.UseVisualStyleBackColor = true;
            button17.Click += btnClear_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.WindowText;
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(39, 76);
            label5.Name = "label5";
            label5.Size = new Size(36, 17);
            label5.TabIndex = 21;
            label5.Text = "       ";
            label5.Click += label5_Click;
            // 
            // button11
            // 
            button11.Location = new Point(4, 4);
            button11.Name = "button11";
            button11.Size = new Size(75, 23);
            button11.TabIndex = 22;
            button11.Text = "我的吐槽";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(298, 450);
            Controls.Add(button11);
            Controls.Add(label5);
            Controls.Add(button17);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "计算器";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button17;
        private Label label5;
        private Button button11;
    }
}

namespace 计算器//上次的改进版，这次用了更好用的.NET
{
    public partial class Form1 : Form
    {
        private double num1 = 0;//我C语言会一点，C#应该没问题吧......
        private double num2 = 0;
        private string op = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void btnNum_Click(object sender, EventArgs e)//问题多了，这一点也不像C语言
        {
            Button btn = sender as Button;
            string content = btn.Text;
            if (op != "")
            {
                num2 = num2 * 10;
                double num = Convert.ToDouble(content);
                num2 = num2 + num;
                label4.Text = num2.ToString();
            }
            if (op == "")
            {
                num1 = num1 * 10;
                double num = Convert.ToDouble(content);
                num1 = num1 + num;
                label4.Text = num1.ToString();
            }
            label5.Text = $"{num1} {op} {num2}";
        }
        private void btnOp_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string c = btn.Text;
            op = c;
            label5.Text = $"{num1} {op} {num2}";
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            op = "";
            num1 = 0;
            num2 = 0;
            label5.Text = $"{num1} {op} {num2}";
            label4.Text = num1.ToString();
        }
        private void btnEqual_Click(object sender, EventArgs e)
        {
            double result = 0;
            switch (op)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0)
                    {
                        MessageBox.Show("除数不能为0！");
                        return;
                    }
                    result = num1 / num2;
                    break;
                case "":
                    MessageBox.Show("请输入运算符");
                    return;
            }
            MessageBox.Show($"{num1} {op} {num2} = {result}");
            num1 = result;
            num2 = 0;
            op = "";
            label5.Text = $"{num1} {op} {num2}";
            label4.Text = num1.ToString();


        }
        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("C#比Python难写很多，但.NET必须要写C#\n" +
                "......不过.NET写GUI真的很好写，是可视化的，只不过\n" +
                "回调函数什么的要写C#\n" +
                "这个计算器2.0用的就是.NET\n" +
                "不过我得先消化一下C#了......");
        }
    }
}
